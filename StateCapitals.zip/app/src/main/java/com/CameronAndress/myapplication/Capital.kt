package com.CameronAndress.myapplication

class Capital(val state: String, val capitalCity: String)
