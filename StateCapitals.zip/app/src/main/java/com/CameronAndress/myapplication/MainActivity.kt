package com.CameronAndress.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.CameronAndress.myapplication.databinding.ActivityMainBinding
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var stateList: ArrayList<Capital>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Setup view binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load data from string resources
        val rawDataArray = resources.getStringArray(R.array.states)
        stateList = ArrayList()

        // Parse data and populate stateList
        rawDataArray.forEach { item ->
            val (stateName, capitalName) = item.split(",")
            stateList.add(Capital(stateName, capitalName))
        }

        // Display initial random state-capital pair
        displayRandomStateCapital()

        // Button functionality for new random pair
        binding.nextButton.setOnClickListener {
            displayRandomStateCapital()
        }
    }

    // Function to display a random state-capital pair
    private fun displayRandomStateCapital() {
        val randomCapital = stateList[Random.nextInt(stateList.size)]
        binding.capitalInfo.text = "${randomCapital.capitalCity} is the capital of ${randomCapital.state}"
    }

}
